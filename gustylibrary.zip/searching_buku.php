<?php
// Memulai session PHP untuk mengelola login pengguna
session_start();

// Jika pengguna belum login, arahkan ke halaman login
if (!isset($_SESSION['username'])) {
    header("Location: login.php"); // Redirect ke login.php jika belum login
    exit; // Hentikan eksekusi script
}

// Menyertakan koneksi ke database
include 'koneksi.php';

// Mengambil keyword pencarian dari parameter GET 'search', atau kosong jika tidak ada
$keyword = isset($_GET['search']) ? $_GET['search'] : '';

// Query untuk mencari buku berdasarkan judul atau pengarang
$query = "SELECT * FROM buku WHERE judul LIKE '%$keyword%' OR pengarang LIKE '%$keyword%' ORDER BY id DESC";

// Menjalankan query dan menyimpan hasilnya ke variabel $result
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <!-- Pengaturan metadata dasar halaman -->
    <meta charset="UTF-8">
    <title>🔍 Pencarian Buku</title>

    <!-- Menyisipkan Bootstrap CSS dari CDN -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">

    <!-- Style tambahan untuk halaman pencarian -->
    <style>
        body {
            background-image: url('https://i.redd.it/i-was-building-a-library-combined-with-a-museum-v0-6o5xwduguahb1.png?width=3840&format=png&auto=webp&s=7be4950b993fc643f24f73c08d5ddb839a614dd9');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            min-height: 100vh;
            font-family: 'Segoe UI', sans-serif;
            backdrop-filter: brightness(0.95);
        }
        .navbar {
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        .card-search {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            padding: 30px;
            margin-top: 50px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
        }
        h3.search-title {
            font-weight: bold;
            color: #0d6efd;
        }
        .form-control {
            border-radius: 12px;
        }
        .btn-search {
            border-radius: 12px;
            font-weight: 500;
        }
        .table thead {
            background-color: #0d6efd;
            color: white;
        }
        .table th, .table td {
            vertical-align: middle;
        }
        footer {
            background-color: rgba(255,255,255,0.9);
            color: #333;
            font-weight: 500;
        }
    </style>
</head>
<body>

<!-- Navbar Navigasi -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand fw-bold" href="dashboard.php">📚 Perpustakaan Digital</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-between" id="navbarMenu">
            <ul class="navbar-nav">
                <!-- Link menu navigasi -->
                <li class="nav-item"><a class="nav-link" href="data_buku.php">📖 Data Buku</a></li>
                <li class="nav-item"><a class="nav-link" href="data_anggota.php">🧑‍🤝‍🧑 Data Anggota</a></li>
                <li class="nav-item"><a class="nav-link" href="data_petugas.php">👮‍♂️ Data Petugas</a></li>
                <li class="nav-item"><a class="nav-link" href="peminjaman.php">📅 Peminjaman</a></li>
                <li class="nav-item"><a class="nav-link" href="pengembalian.php">📤 Pengembalian</a></li>
                <li class="nav-item"><a class="nav-link active" href="searching_buku.php">🔍 Cari Buku</a></li>
                <li class="nav-item"><a class="nav-link" href="laporan.php">📊 Laporan Transaksi</a></li>
                <li class="nav-item"><a class="nav-link" href="kategori.php">🏷️ Kategori Buku</a></li>
            </ul>
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">🚪 Logout</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Konten utama pencarian -->
<div class="container">
    <div class="card-search">
        <h3 class="search-title mb-4">🔎 Cari Buku Berdasarkan Judul / Pengarang</h3>

        <!-- Form pencarian -->
        <form method="get" class="row g-3 mb-4">
            <div class="col-md-10">
                <!-- Input teks untuk keyword pencarian -->
                <input type="text" name="search" class="form-control form-control-lg" placeholder="Contoh: Laskar Pelangi atau Andrea Hirata" value="<?= htmlspecialchars($keyword); ?>">
            </div>
            <div class="col-md-2 d-grid">
                <!-- Tombol submit untuk pencarian -->
                <button class="btn btn-primary btn-lg btn-search text-white">Cari</button>
            </div>
        </form>

        <!-- Tabel hasil pencarian -->
        <div class="table-responsive">
            <table class="table table-bordered table-hover text-center">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>📖 Judul</th>
                        <th>✍️ Pengarang</th>
                        <th>🏢 Penerbit</th>
                        <th>📅 Tahun</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1; // Nomor urut awal
                    // Jika ada hasil dari pencarian
                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                    ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><?= $row['judul']; ?></td>
                            <td><?= $row['pengarang']; ?></td>
                            <td><?= $row['penerbit']; ?></td>
                            <td><?= $row['tahun']; ?></td>
                        </tr>
                    <?php
                        }
                    } else {
                        // Jika tidak ada hasil ditemukan
                        echo "<tr><td colspan='5' class='text-muted'>❗ Tidak ada hasil ditemukan.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Footer -->
<footer class="text-center py-3 mt-4">
    &copy; <?= date('Y'); ?> Gusty Aranda Bachtyar - 2023230023.
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
