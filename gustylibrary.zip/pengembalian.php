<?php
// Memulai session untuk mengecek status login
session_start();

// Jika pengguna belum login, alihkan ke halaman login
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit; // Menghentikan eksekusi lebih lanjut
}

// Menyertakan file koneksi ke database
include 'koneksi.php';

// Jika tombol simpan ditekan (proses tambah pengembalian)
if (isset($_POST['simpan'])) {
    $id_peminjaman = $_POST['id_peminjaman']; // Mengambil ID peminjaman dari form
    $tanggal_kembali = $_POST['tanggal_kembali']; // Mengambil tanggal kembali dari form

    // Menghapus karakter non-angka dari input denda (misal titik atau koma)
    $denda = preg_replace("/[^0-9]/", "", $_POST['denda']);

    // Menyimpan data pengembalian ke dalam tabel pengembalian
    mysqli_query($conn, "INSERT INTO pengembalian (id_peminjaman, tanggal_kembali, denda) 
                         VALUES ('$id_peminjaman', '$tanggal_kembali', '$denda')");

    // Mengarahkan kembali ke halaman pengembalian
    header("Location: pengembalian.php");
}

// Mengambil data pengembalian dengan join dari tabel buku, anggota, dan peminjaman
$result = mysqli_query($conn, "
    SELECT pg.id, b.judul, a.nama, p.tanggal_pinjam, pg.tanggal_kembali, pg.denda
    FROM pengembalian pg
    JOIN peminjaman p ON pg.id_peminjaman = p.id
    JOIN buku b ON p.id_buku = b.id
    JOIN anggota a ON p.id_anggota = a.id
    ORDER BY pg.id DESC
");

// Mengambil semua data peminjaman untuk dropdown di form tambah
$peminjaman = mysqli_query($conn, "
    SELECT p.id, b.judul, a.nama 
    FROM peminjaman p
    JOIN buku b ON p.id_buku = b.id
    JOIN anggota a ON p.id_anggota = a.id
");
?>

<!DOCTYPE html>
<html>
<head>
    <!-- Judul halaman -->
    <title>Data Pengembalian Buku</title>
    <!-- Mengimpor Bootstrap untuk tampilan yang responsif -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        /* Styling untuk latar belakang dan elemen visual */
        body {
            background-image: url('https://external-preview.redd.it/ggdIOwTZgR9ug01mTXX1cWc1Krk0PSDc75gcLaU-9a0.png?format=pjpg&auto=webp&s=5d474e131cfe2f27341f6a0bdd24fc2a308ccf9d');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            min-height: 100vh;
            font-family: 'Segoe UI', sans-serif;
            backdrop-filter: brightness(0.95);
        }
        .card {
            border-radius: 16px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.08);
            background: rgba(255, 255, 255, 0.95);
        }
        .btn-success {
            background-color: #28a745;
            border: none;
        }
        .btn-success:hover {
            background-color: #218838;
        }
        h3 {
            font-weight: 600;
            color: #1e90ff;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
    <div class="container">
        <!-- Judul navbar -->
        <a class="navbar-brand fw-bold" href="dashboard.php">📚 Perpustakaan Digital</a>
        <!-- Tombol toggle untuk layar kecil -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <!-- Menu navbar -->
        <div class="collapse navbar-collapse justify-content-between" id="navbarMenu">
            <ul class="navbar-nav">
                <!-- Daftar menu navigasi -->
                <li class="nav-item"><a class="nav-link" href="data_buku.php">📖 Data Buku</a></li>
                <li class="nav-item"><a class="nav-link" href="data_anggota.php">🧑‍🤝‍🧑 Data Anggota</a></li>
                <li class="nav-item"><a class="nav-link" href="data_petugas.php">👮‍♂️ Data Petugas</a></li>
                <li class="nav-item"><a class="nav-link" href="peminjaman.php">📅 Peminjaman</a></li>
                <li class="nav-item"><a class="nav-link active" href="pengembalian.php">📤 Pengembalian</a></li>
                <li class="nav-item"><a class="nav-link" href="searching_buku.php">🔍 Cari Buku</a></li>
                <li class="nav-item"><a class="nav-link" href="laporan.php">📊 Laporan Transaksi</a></li>
                <li class="nav-item"><a class="nav-link" href="kategori.php">🏷️ Kategori Buku</a></li>
            </ul>
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">🚪 Logout</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Konten utama -->
<div class="container mt-5">
    <!-- Header dan tombol tambah -->
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>📤 Data Pengembalian Buku</h3>
        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modalTambah">+ Tambah Pengembalian</button>
    </div>

    <!-- Tabel data pengembalian -->
    <div class="card p-4">
        <table class="table table-hover table-bordered text-center align-middle">
            <thead class="table-light">
                <tr>
                    <th>No</th>
                    <th>Judul Buku</th>
                    <th>Nama Anggota</th>
                    <th>Tanggal Pinjam</th>
                    <th>Tanggal Kembali</th>
                    <th>Denda</th>
                </tr>
            </thead>
            <tbody>
                <!-- Menampilkan data pengembalian dari database -->
                <?php $no = 1; while ($row = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td><?= $row['judul']; ?></td>
                    <td><?= $row['nama']; ?></td>
                    <td><?= $row['tanggal_pinjam']; ?></td>
                    <td><?= $row['tanggal_kembali']; ?></td>
                    <td>Rp <?= number_format($row['denda'], 0, ',', '.'); ?></td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal untuk tambah data pengembalian -->
<div class="modal fade" id="modalTambah">
  <div class="modal-dialog">
    <form method="post" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Form Pengembalian</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <!-- Dropdown untuk memilih data peminjaman -->
        <div class="mb-3">
            <label class="form-label">Pilih Peminjaman</label>
            <select name="id_peminjaman" class="form-control" required>
                <option value="">-- Pilih --</option>
                <?php while ($p = mysqli_fetch_assoc($peminjaman)) { ?>
                    <option value="<?= $p['id']; ?>"><?= $p['judul'] . " - " . $p['nama']; ?></option>
                <?php } ?>
            </select>
        </div>
        <!-- Input tanggal kembali -->
        <div class="mb-3">
            <label class="form-label">Tanggal Kembali</label>
            <input type="date" name="tanggal_kembali" class="form-control" required>
        </div>
        <!-- Input denda -->
        <div class="mb-3">
            <label class="form-label">Denda (Rp)</label>
            <input type="text" name="denda" class="form-control" id="denda" value="0" required>
        </div>
      </div>
      <!-- Tombol simpan -->
      <div class="modal-footer">
        <button class="btn btn-primary" name="simpan">Simpan</button>
      </div>
    </form>
  </div>
</div>

<!-- Script Bootstrap -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- Script untuk formatting input denda -->
<script>
document.getElementById('denda').addEventListener('input', function (e) {
    let value = e.target.value.replace(/\D/g, ''); // Menghapus karakter non-digit
    let formatted = new Intl.NumberFormat('id-ID').format(value); // Format angka sesuai Indonesia
    e.target.value = formatted; // Set nilai input yang sudah diformat
});
</script>

<!-- Footer -->
<footer class="text-center py-3 mt-4" style="background-color: rgba(255,255,255,0.9); color: #333; font-weight: 500;">
    &copy; <?= date('Y'); ?> Gusty Aranda Bachtyar - 2023230023.
</footer>

</body>
</html>