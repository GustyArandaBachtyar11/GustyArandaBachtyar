<?php
// index.php
// Halaman awal atau beranda
?>
<!DOCTYPE html> <!-- Menentukan jenis dokumen HTML5 -->
<html>
<head>
    <title>Perpustakaan</title> <!-- Judul halaman yang akan tampil di tab browser -->

    <!-- ============================
         LINK CSS BOOTSTRAP 
         ============================
         Pertama: Menggunakan CDN agar tetap tampil meskipun file lokal tidak ditemukan
         Kedua: Link lokal sebagai backup jika CDN gagal (opsional)
    -->
    
    <!-- Menggunakan Bootstrap versi 5.3.0 dari CDN -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">

    <!-- Sebagai backup: Memuat file CSS Bootstrap dari folder lokal assets/css -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
</head>
<body>

<!-- ============================
     NAVBAR / MENU ATAS
     ============================
     Menggunakan komponen navbar dari Bootstrap dengan tema gelap (dark) dan warna biru (bg-primary)
-->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container"> <!-- Membuat isi navbar sejajar dan memiliki jarak otomatis -->

        <!-- Logo atau brand nama di sebelah kiri -->
        <a class="navbar-brand" href="#">Perpustakaan</a>
        
        <!-- Navigasi bagian kanan halaman (login) -->
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav ms-auto"> <!-- ms-auto = margin start auto (untuk mendorong menu ke kanan) -->
                <!-- Menu Login Admin -->
                <li class="nav-item">
                    <a href="login.php" class="nav-link">Login Admin</a> <!-- Tautan ke halaman login admin -->
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- ============================
     KONTEN UTAMA
     ============================
     Berisi ucapan selamat datang dan deskripsi singkat
-->
<div class="container mt-4"> <!-- mt-4 = margin top 4 (untuk memberi jarak dari atas) -->

    <!-- Judul besar halaman, diratakan ke tengah -->
    <h1 class="text-center">Selamat Datang di Perpustakaan Digital</h1>

    <!-- Deskripsi singkat, juga diratakan ke tengah -->
    <p class="text-center">Cari dan kelola data buku dengan mudah.</p>
</div>

</body>
</html>
