<?php
// Deklarasi class Buku untuk menangani operasi database terkait buku
class Buku {
    private $conn; // Properti private untuk menyimpan koneksi database

    // Konstruktor class Buku, menerima parameter koneksi database
    public function __construct($db) {
        $this->conn = $db; // Simpan koneksi database ke properti class
    }

    // Fungsi untuk mengambil semua data buku beserta nama kategori
    public function getAll() {
        $sql = "SELECT b.*, k.nama_kategori 
                FROM tbl_buku b 
                LEFT JOIN tbl_kategori k ON b.id_kategori = k.id_kategori 
                ORDER BY b.id_buku DESC"; // Query untuk join buku dan kategori, urutkan berdasarkan ID buku menurun
        return mysqli_query($this->conn, $sql); // Jalankan query dan kembalikan hasilnya
    }

    // Fungsi untuk mengedit data buku
    public function edit($data, $file) {
        $id = $data['id_buku'];                    // Ambil ID buku dari data
        $judul = $data['judul'];                   // Ambil judul baru
        $penulis = $data['penulis'];               // Ambil nama penulis baru
        $stok = $data['stok'];                     // Ambil jumlah stok baru
        $id_kategori = $data['id_kategori'];       // Ambil ID kategori baru
        $gambar_lama = $data['gambar_lama'];       // Ambil nama file gambar lama
        $gambar_baru = $file['gambar']['name'];    // Ambil nama file gambar baru (jika ada)

        // Jika ada gambar baru yang diupload
        if ($gambar_baru) {
            $nama_file = time() . '_' . $gambar_baru; // Buat nama file baru dengan timestamp agar unik
            $tmp = $file['gambar']['tmp_name'];       // Ambil lokasi sementara file upload
            $lokasi = "../uploads/gambar_buku/" . $nama_file; // Tentukan lokasi tujuan penyimpanan file
            move_uploaded_file($tmp, $lokasi);        // Pindahkan file ke folder tujuan

            // Hapus gambar lama jika masih ada di folder
            if (file_exists("../uploads/gambar_buku/" . $gambar_lama)) {
                unlink("../uploads/gambar_buku/" . $gambar_lama); // Hapus file gambar lama dari folder
            }
        } else {
            $nama_file = $gambar_lama; // Jika tidak upload gambar baru, gunakan gambar lama
        }

        // Query untuk update data buku
        $query = "UPDATE tbl_buku 
                  SET judul='$judul', penulis='$penulis', stok=$stok, gambar='$nama_file', id_kategori=$id_kategori 
                  WHERE id_buku = $id";
        return mysqli_query($this->conn, $query); // Jalankan query update dan kembalikan hasilnya
    }

    // Fungsi untuk menambahkan data buku baru
    public function tambah($data, $file) {
        $judul       = $data['judul'];             // Ambil judul buku
        $penulis     = $data['penulis'];           // Ambil nama penulis
        $stok        = $data['stok'];              // Ambil stok buku
        $id_kategori = $data['id_kategori'];       // Ambil ID kategori buku

        // Buat nama file unik untuk gambar yang diupload
        $nama_file = time() . '_' . $file['gambar']['name'];
        $tmp       = $file['gambar']['tmp_name'];  // Ambil lokasi sementara file gambar
        $lokasi    = "NEW UAS PEMROGRAMAN WEB LANJUTAN PRAKTEK" . $nama_file; // Lokasi penyimpanan file (catatan: ini bukan folder valid)

        move_uploaded_file($tmp, $lokasi);         // Pindahkan file ke lokasi tujuan

        // Query untuk memasukkan data buku baru ke database
        $query = "INSERT INTO tbl_buku (judul, penulis, stok, gambar, id_kategori)
                  VALUES ('$judul', '$penulis', $stok, '$nama_file', $id_kategori)";
        return mysqli_query($this->conn, $query);  // Jalankan query insert dan kembalikan hasilnya
    }

    // Fungsi untuk menghapus data buku
    public function hapus($id, $gambar) {
        unlink("../uploads/gambar_buku/" . $gambar); // Hapus gambar terkait dari folder upload
        return mysqli_query($this->conn, "DELETE FROM tbl_buku WHERE id_buku = $id"); // Jalankan query delete
    }
}
?>
