<?php
// Memulai sesi untuk menjaga autentikasi pengguna
session_start();

// Jika sesi login belum ada, arahkan ke halaman login.php
if (!isset($_SESSION['username'])) {
    header("Location: login.php"); // Redirect ke login jika belum login
    exit; // Hentikan eksekusi kode berikutnya
}

// Menyertakan file koneksi ke database
include 'koneksi.php';

// Jika form tambah data dikirimkan
if (isset($_POST['simpan'])) {
    $nama = $_POST['nama']; // Ambil input nama dari form
    $kelas = $_POST['kelas']; // Ambil input kelas dari form
    $alamat = $_POST['alamat']; // Ambil input alamat dari form

    // Query untuk menyimpan data ke tabel anggota
    mysqli_query($conn, "INSERT INTO anggota (nama, kelas, alamat) VALUES ('$nama', '$kelas', '$alamat')");
    
    header("Location: data_anggota.php"); // Kembali ke halaman data anggota
}

// Jika tombol hapus ditekan (parameter GET 'hapus')
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus']; // Ambil ID dari URL
    mysqli_query($conn, "DELETE FROM anggota WHERE id = $id"); // Hapus data berdasarkan ID
    header("Location: data_anggota.php"); // Kembali ke halaman
}

// Jika form edit/update dikirimkan
if (isset($_POST['update'])) {
    $id = $_POST['id']; // Ambil ID dari input form
    $nama = $_POST['nama']; // Ambil nama baru
    $kelas = $_POST['kelas']; // Ambil kelas baru
    $alamat = $_POST['alamat']; // Ambil alamat baru

    // Query update data anggota berdasarkan ID
    mysqli_query($conn, "UPDATE anggota SET nama='$nama', kelas='$kelas', alamat='$alamat' WHERE id=$id");
    
    header("Location: data_anggota.php"); // Redirect setelah update
}

// Ambil semua data anggota dari database
$result = mysqli_query($conn, "SELECT * FROM anggota ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Anggota</title> <!-- Judul halaman -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"> <!-- CSS Bootstrap -->
    <style>
        body {
            background: url('https://i.ytimg.com/vi/RzeBvx5m9gg/maxresdefault.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: 'Segoe UI', sans-serif;
            position: relative;
        }
        body::before {
            content: "";
            position: fixed;
            top: 0; left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255,255,255,0.6);
            z-index: -1;
        }
        .navbar {
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .table thead {
            background-color: #2c3e50;
            color: white;
        }
        .card-box {
            background: rgba(255, 255, 255, 0.9);
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.08);
        }
        .btn-sm {
            font-size: 0.85rem;
        }
    </style>
</head>
<body>

<!-- Navigasi atas -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
    <a class="navbar-brand fw-bold" href="dashboard.php">📚 Perpustakaan Digital</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-between" id="navbarMenu">
            <ul class="navbar-nav">
                <!-- Menu navigasi -->
                <li class="nav-item"><a class="nav-link" href="data_buku.php">📖 Data Buku</a></li>
                <li class="nav-item"><a class="nav-link active" href="data_anggota.php">🧑‍🤝‍🧑 Data Anggota</a></li>
                <li class="nav-item"><a class="nav-link" href="data_petugas.php">👮‍♂️ Data Petugas</a></li>
                <li class="nav-item"><a class="nav-link" href="peminjaman.php">📅 Peminjaman</a></li>
                <li class="nav-item"><a class="nav-link" href="pengembalian.php">📤 Pengembalian</a></li>
                <li class="nav-item"><a class="nav-link" href="searching_buku.php">🔍 Cari Buku</a></li>
                <li class="nav-item"><a class="nav-link" href="laporan.php">📊 Laporan Transaksi</a></li>
                <li class="nav-item"><a class="nav-link" href="kategori.php">🏷️ Kategori Buku</a></li>
            </ul>
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="logout.php">🚪 Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<!-- Konten utama -->
<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3 class="text-primary">🧑‍🤝‍🧑 Data Anggota</h3> <!-- Judul halaman -->
        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modalTambah">+ Tambah Anggota</button>
    </div>

    <!-- Tabel anggota -->
    <div class="card-box">
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Kelas</th>
                    <th>Alamat</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; while ($row = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td><?= $no++; ?></td> <!-- Nomor urut -->
                    <td><?= $row['nama']; ?></td> <!-- Nama anggota -->
                    <td><?= $row['kelas']; ?></td> <!-- Kelas anggota -->
                    <td><?= $row['alamat']; ?></td> <!-- Alamat anggota -->
                    <td>
                        <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#modalEdit<?= $row['id']; ?>">✏️ Edit</button>
                        <a href="?hapus=<?= $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Hapus data ini?')">🗑️ Hapus</a>
                    </td>
                </tr>

                <!-- Modal Edit -->
                <div class="modal fade" id="modalEdit<?= $row['id']; ?>">
                    <div class="modal-dialog">
                        <form method="post" class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Edit Anggota</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                <input type="hidden" name="id" value="<?= $row['id']; ?>">
                                <div class="mb-2">
                                    <label>Nama</label>
                                    <input type="text" name="nama" class="form-control" value="<?= $row['nama']; ?>" required>
                                </div>
                                <div class="mb-2">
                                    <label>Kelas</label>
                                    <input type="text" name="kelas" class="form-control" value="<?= $row['kelas']; ?>" required>
                                </div>
                                <div class="mb-2">
                                    <label>Alamat</label>
                                    <textarea name="alamat" class="form-control" required><?= $row['alamat']; ?></textarea>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button class="btn btn-primary" name="update">💾 Simpan Perubahan</button>
                            </div>
                        </form>
                    </div>
                </div>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Tambah Anggota -->
<div class="modal fade" id="modalTambah">
    <div class="modal-dialog">
        <form method="post" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Tambah Anggota</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-2">
                    <label>Nama</label>
                    <input type="text" name="nama" class="form-control" placeholder="Masukkan nama" required>
                </div>
                <div class="mb-2">
                    <label>Kelas</label>
                    <input type="text" name="kelas" class="form-control" placeholder="Masukkan kelas" required>
                </div>
                <div class="mb-2">
                    <label>Alamat</label>
                    <textarea name="alamat" class="form-control" placeholder="Masukkan alamat" required></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-success" name="simpan">💾 Simpan</button>
            </div>
        </form>
    </div>
</div>

<!-- Footer halaman -->
<footer class="text-center py-3 mt-4" style="background-color: rgba(255,255,255,0.9); color: #333; font-weight: 500;">
    &copy; <?= date('Y'); ?> Gusty Aranda Bachtyar - 2023230023.
</footer>

<!-- Script Bootstrap -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>