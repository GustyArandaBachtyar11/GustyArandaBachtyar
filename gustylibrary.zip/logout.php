<?php
// logout.php
// Script untuk mengakhiri session dan keluar dari aplikasi

session_start();              // Memulai session untuk memastikan kita bisa menghancurkannya

session_unset();              // Menghapus semua variabel session
session_destroy();           // Menghancurkan session yang sedang aktif

header("Location: login.php"); // Redirect user kembali ke halaman login
exit();                       // Menghentikan eksekusi script
?>
