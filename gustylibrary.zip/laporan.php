<?php
// Memulai session untuk mengecek apakah pengguna sudah login
session_start();

// Jika belum login, redirect ke halaman login
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

// Menghubungkan ke file koneksi database
include 'koneksi.php';

// Query untuk mengambil data laporan transaksi yang sudah dikembalikan
$query = "
    SELECT b.judul, a.nama, p.tanggal_pinjam, k.tanggal_kembali, k.denda
    FROM pengembalian k
    JOIN peminjaman p ON k.id_peminjaman = p.id
    JOIN buku b ON p.id_buku = b.id
    JOIN anggota a ON p.id_anggota = a.id
    ORDER BY k.id DESC
";

// Menjalankan query dan menyimpan hasilnya ke variabel $result
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>📊 Laporan Transaksi</title> <!-- Judul halaman -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        /* Styling background dan tampilan halaman */
        body {
            background-image: url('https://i.redd.it/mycd366prku71.png');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            min-height: 100vh;
            font-family: 'Segoe UI', sans-serif;
            backdrop-filter: brightness(0.93);
        }
        .navbar {
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        .report-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            padding: 30px;
            margin-top: 50px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
        }
        h3.title {
            font-weight: bold;
            color: #0d6efd;
        }
        .table thead {
            background-color: #0d6efd;
            color: white;
        }
        .table td, .table th {
            vertical-align: middle;
        }
        footer {
            background-color: rgba(255,255,255,0.9);
            color: #333;
            font-weight: 500;
        }
    </style>
</head>
<body>

<!-- Navbar navigasi utama -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand fw-bold" href="dashboard.php">📚 Perpustakaan Digital</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-between" id="navbarMenu">
            <ul class="navbar-nav">
                <!-- Link ke setiap halaman data -->
                <li class="nav-item"><a class="nav-link" href="data_buku.php">📖 Data Buku</a></li>
                <li class="nav-item"><a class="nav-link" href="data_anggota.php">🧑‍🤝‍🧑 Data Anggota</a></li>
                <li class="nav-item"><a class="nav-link" href="data_petugas.php">👮‍♂️ Data Petugas</a></li>
                <li class="nav-item"><a class="nav-link" href="peminjaman.php">📅 Peminjaman</a></li>
                <li class="nav-item"><a class="nav-link" href="pengembalian.php">📤 Pengembalian</a></li>
                <li class="nav-item"><a class="nav-link" href="searching_buku.php">🔍 Cari Buku</a></li>
                <li class="nav-item"><a class="nav-link active" href="laporan.php">📊 Laporan Transaksi</a></li>
                <li class="nav-item"><a class="nav-link" href="kategori.php">🏷️ Kategori Buku</a></li>
            </ul>
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="logout.php">🚪 Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<!-- Konten laporan -->
<div class="container">
    <div class="report-card">
        <h3 class="mb-4 title">📊 Laporan Transaksi Peminjaman & Pengembalian</h3>

        <div class="table-responsive">
            <table class="table table-bordered table-hover text-center">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>📖 Judul Buku</th>
                        <th>👤 Nama Anggota</th>
                        <th>📅 Tanggal Pinjam</th>
                        <th>📅 Tanggal Kembali</th>
                        <th>💰 Denda</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1; // Inisialisasi nomor urut
                    if (mysqli_num_rows($result) > 0) {
                        // Menampilkan setiap baris data hasil query
                        while ($row = mysqli_fetch_assoc($result)) {
                    ?>
                    <tr>
                        <td><?= $no++; ?></td> <!-- Nomor urut -->
                        <td><?= $row['judul']; ?></td> <!-- Judul buku -->
                        <td><?= $row['nama']; ?></td> <!-- Nama anggota -->
                        <td><?= date('d-m-Y', strtotime($row['tanggal_pinjam'])); ?></td> <!-- Tanggal pinjam -->
                        <td><?= date('d-m-Y', strtotime($row['tanggal_kembali'])); ?></td> <!-- Tanggal kembali -->
                        <td>Rp <?= number_format($row['denda'], 0, ',', '.'); ?></td> <!-- Denda dalam format rupiah -->
                    </tr>
                    <?php } } else { ?>
                    <tr>
                        <td colspan="6" class="text-muted">❗ Tidak ada transaksi ditemukan.</td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Footer bagian bawah halaman -->
<footer class="text-center py-3 mt-4">
    &copy; <?= date('Y'); ?> Gusty Aranda Bachtyar - 2023230023.
</footer>

<!-- Script Bootstrap -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
