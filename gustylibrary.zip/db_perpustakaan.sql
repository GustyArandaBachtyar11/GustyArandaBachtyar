-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 06, 2025 at 08:41 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_perpustakaan`
--

-- --------------------------------------------------------

--
-- Table structure for table `anggota`
--

CREATE TABLE `anggota` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `kelas` varchar(10) DEFAULT NULL,
  `alamat` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `anggota`
--

INSERT INTO `anggota` (`id`, `nama`, `kelas`, `alamat`) VALUES
(1, 'Ahmad Fauzi', 'X IPA 1', 'Jl. Melati No. 12'),
(2, 'Siti Nurhaliza', 'XI IPS 2', 'Jl. Mawar No. 8'),
(3, 'Budi Santoso', 'XII IPA 3', 'Jl. Kenanga No. 5'),
(4, 'Rina Kartika', 'X IPS 1', 'Jl. Anggrek No. 20'),
(5, 'Dedi Saputra', 'XI IPA 2', 'Jl. Flamboyan No. 14'),
(6, 'Lina Marlina', 'XII IPS 1', 'Jl. Dahlia No. 33'),
(7, 'Andi Firmansyah', 'X IPA 2', 'Jl. Cempaka No. 17'),
(8, 'Nur Aisyah', 'XI IPS 3', 'Jl. Teratai No. 6'),
(9, 'Hendra Wijaya', 'XII IPA 1', 'Jl. Kamboja No. 9'),
(10, 'Melati Ramadhani', 'X IPS 2', 'Jl. Tulip No. 11'),
(13, 'Bambang', 'X IPS 2', 'Jl. Kampung Melayu No. 22'),
(14, 'Nurjanah', 'X IPA 1', 'Jl. Ciamis Lakbok '),
(15, 'Gusty Aranda Bachtyar', 'XII IPA 2', 'Jl. Bintarajaya Bekasi Barat Kota Bekasi No. 11'),
(16, 'Nony Pudjastuti', 'XII IPA 1', 'Jl. Duren Sawit Jakarta Timur No. 12');

-- --------------------------------------------------------

--
-- Table structure for table `buku`
--

CREATE TABLE `buku` (
  `id` int(11) NOT NULL,
  `judul` varchar(100) DEFAULT NULL,
  `pengarang` varchar(100) DEFAULT NULL,
  `penerbit` varchar(100) DEFAULT NULL,
  `tahun` int(11) DEFAULT NULL,
  `id_kategori` int(11) DEFAULT NULL,
  `sampul` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `buku`
--

INSERT INTO `buku` (`id`, `judul`, `pengarang`, `penerbit`, `tahun`, `id_kategori`, `sampul`) VALUES
(46, 'Dilan: Dia adalah Dilanku 1990', 'Pidi Baiq', 'Pastel Books', 2014, 18, 'Dilan-Dia-Adalah-Dilanku-tahun-1990-Pidi-Baiq-front.jpg'),
(47, 'Ayat-Ayat Cinta', 'Habiburrahman El Shirazy', 'Republika', 2004, 18, 'Ayat-Ayat Cinta.jpg'),
(48, 'Laskar Pelangi', 'Andrea Hirata', 'Bentang Pustaka', 2005, 18, 'Laskar Pelangi.jpg'),
(49, 'Sang Pemimpi', 'Andrea Hirata', 'Bentang Pustaka', 2006, 18, 'Sang Pemimpi.jpg'),
(50, 'One Piece', 'Eiichiro Oda', 'Shueisha', 1997, 19, 'One Piece.jpg'),
(51, 'Naruto', 'Masashi Kishimoto', 'Shueisha', 1999, 19, 'Naruto.jpg'),
(52, 'Dragon Ball', 'Akira Toriyama', 'Shueisha', 1984, 19, 'Dragon Ball.jpg'),
(53, 'Doraemon', 'Fujiko F. Fujio', 'Shogakukan', 1970, 19, 'Doraemon.jpg'),
(54, 'Kamus Besar Bahasa Indonesia', 'Tim KBBI', 'Badan Pengembangan Bahasa', 2016, 20, 'Kamus Besar Bahasa Indonesia.jpg'),
(55, 'Ejaan Bahasa Indonesia yang Disempurnakan', 'Tim Pusat Bahasa', 'Pusat Bahasa', 2008, 20, 'Ejaan Bahasa Indonesia yang Disempurnakan.jpg'),
(56, 'Bahasa Indonesia untuk Perguruan Tinggi', 'Gorys Keraf', 'Nusa Indah', 2000, 20, 'Bahasa Indonesia untuk Perguruan Tinggi.jpg'),
(57, 'Tata Bahasa Baku Bahasa Indonesia', 'Anton Moeliono', 'Balai Pustaka', 1988, 20, 'Tata Bahasa Baku Bahasa Indonesia.jpg'),
(58, 'Bangkit dan Runtuhnya Kerajaan Majapahit', 'Slamet Muljana', 'LKiS', 2005, 21, 'Bangkit dan Runtuhnya Kerajaan Majapahit.jpg'),
(59, 'Sejarah Nasional Indonesia (Jilid 1–6)', 'Nugroho Notosusanto (editor)', 'Balai Pustaka', 1990, 21, 'Sejarah Nasional Indonesia (Jilid 1–6).png'),
(60, 'Dari Sabang ke Merauke: Sejarah Indonesia', 'A. Sartono Kartodirdjo', 'Gramedia', 1987, 21, 'Ini bukan sekadar pertunjukan. Ini adalah perayaan budaya Nusantara.351 penari dan puluhan alat musik tradisional akan menghidupkan Hikayat Nusantara di panggung megah Pagelaran Sabang Merauke 2025. Jangan lewatkan!.jpg'),
(61, 'G30S: Sejarah yang Digelapkan', 'John Roosa', 'Hasta Mitra', 2008, 21, 'G30S Sejarah yang Digelapkan.jpg'),
(62, 'Pengantar Teknologi Informasi', 'Rainer & Turban', 'Salemba Empat', 2015, 22, 'Pengantar Teknologi Informasi.jpg'),
(63, 'Teknologi Informasi dan Komunikasi', 'Nana Syaodih Sukmadinata', 'Yudhistira', 2018, 22, 'Teknologi Informasi dan Komunikasi.jpg'),
(64, 'Teknologi Komputer dan Informatika Dasar', 'Wahana Komputer', 'Andi Offset', 2019, 22, 'Teknologi Komputer dan Informatika Dasar.jpg'),
(65, 'Teknologi Cloud Computing', 'Rahmat Mulyana', 'Informatika Bandung', 2020, 22, 'Teknologi Cloud Computing.jpg'),
(66, 'Landasan Pendidikan', 'Zuhairini et al.', 'Bumi Aksara', 2013, 23, 'Landasan Pendidikan.jpg'),
(67, 'Filsafat Pendidikan', 'Ahmad D. Marimba', 'Rosda', 2005, 23, 'Filsafat Pendidikan.jpg'),
(68, 'Pengantar Ilmu Pendidikan', 'Djahiri Kosasih', 'Pustaka Setia', 2009, 23, 'Pengantar Ilmu Pendidikan.jpg'),
(69, 'Psikologi Pendidikan', 'Nana Syaodih Sukmadinata', 'Remaja Rosdakarya', 2012, 23, 'Psikologi Pendidikan new.jpg'),
(70, 'Sejarah Perkembangan Islam di Indonesia', 'Prof. Dr. Taufik Abdullah (editor)', 'LP3ES', 2002, 24, 'Sejarah Perkembangan Islam di Indonesia.jpg'),
(71, 'Sejarah Nabi Muhammad SAW', 'Ibn Ishaq', 'Pustaka Al-Kautsar', 2005, 24, 'Sejarah Nabi Muhammad SAW.jpg'),
(72, 'Al-Quran dan Terjemahannya', 'Tim Depag RI', 'Departemen Agama RI', 2002, 24, 'Al-Quran dan Terjemahannya.jpg'),
(73, 'Dialog Antaragama di Dunia Global', 'Hans Küng', 'Gramedia', 2011, 24, 'Dialog Antaragama di Dunia Global.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id`, `nama`) VALUES
(18, 'Novel'),
(19, 'Komik'),
(20, 'Bahasa Indonesia'),
(21, 'Sejarah'),
(22, 'Teknologi'),
(23, 'Pendidikan'),
(24, 'Agama');

-- --------------------------------------------------------

--
-- Table structure for table `peminjaman`
--

CREATE TABLE `peminjaman` (
  `id` int(11) NOT NULL,
  `id_buku` int(11) DEFAULT NULL,
  `id_anggota` int(11) DEFAULT NULL,
  `tanggal_pinjam` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `peminjaman`
--

INSERT INTO `peminjaman` (`id`, `id_buku`, `id_anggota`, `tanggal_pinjam`) VALUES
(8, 48, 1, '2025-07-01'),
(9, 46, 2, '2025-07-02'),
(10, 50, 3, '2025-07-03'),
(11, 53, 4, '2025-07-04'),
(12, 54, 5, '2025-07-05'),
(13, 55, 6, '2025-07-06'),
(14, 58, 7, '2025-07-07'),
(15, 61, 8, '2025-07-08'),
(16, 62, 9, '2025-07-09'),
(17, 63, 10, '2025-07-10'),
(18, 68, 15, '2025-07-11'),
(19, 69, 16, '2025-07-12'),
(21, 70, 13, '2025-07-13'),
(22, 71, 14, '2025-07-14');

-- --------------------------------------------------------

--
-- Table structure for table `pengembalian`
--

CREATE TABLE `pengembalian` (
  `id` int(11) NOT NULL,
  `id_peminjaman` int(11) DEFAULT NULL,
  `tanggal_kembali` date DEFAULT NULL,
  `denda` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pengembalian`
--

INSERT INTO `pengembalian` (`id`, `id_peminjaman`, `tanggal_kembali`, `denda`) VALUES
(9, 8, '2025-07-15', 35000),
(10, 9, '2025-07-16', 30000),
(11, 10, '2025-07-17', 25000),
(12, 11, '2025-07-18', 30000),
(13, 12, '2025-07-19', 35000),
(14, 13, '2025-07-20', 25000),
(15, 14, '2025-07-21', 30000),
(16, 15, '2025-07-22', 30000),
(17, 16, '2025-07-23', 25000),
(18, 17, '2025-07-24', 30000),
(20, 18, '2025-07-25', 35000),
(21, 19, '2025-07-26', 35000),
(22, 21, '2025-07-27', 30000),
(23, 22, '2025-07-28', 25000);

-- --------------------------------------------------------

--
-- Table structure for table `petugas`
--

CREATE TABLE `petugas` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `no_hp` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `petugas`
--

INSERT INTO `petugas` (`id`, `nama`, `no_hp`) VALUES
(1, 'Rudi Hartono', '0812-3456-7890'),
(2, 'Sari Melinda', '0821-7788-9911'),
(3, 'Dwi Purnama', '0857-1234-5678'),
(4, 'Lina Kusuma', '0813-9999-0001'),
(5, 'Fajar Ramadhan', '0882-3344-5566'),
(6, 'Ratna Sari Dewi', '0877-5566-7788'),
(7, 'Beni Suhendra', '0819-2020-3030'),
(8, 'Arif Hidayat', '0822-5678-1234');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `anggota`
--
ALTER TABLE `anggota`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `buku`
--
ALTER TABLE `buku`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `peminjaman`
--
ALTER TABLE `peminjaman`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_buku` (`id_buku`),
  ADD KEY `id_anggota` (`id_anggota`);

--
-- Indexes for table `pengembalian`
--
ALTER TABLE `pengembalian`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_peminjaman` (`id_peminjaman`);

--
-- Indexes for table `petugas`
--
ALTER TABLE `petugas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `anggota`
--
ALTER TABLE `anggota`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `buku`
--
ALTER TABLE `buku`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `peminjaman`
--
ALTER TABLE `peminjaman`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `pengembalian`
--
ALTER TABLE `pengembalian`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `petugas`
--
ALTER TABLE `petugas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `peminjaman`
--
ALTER TABLE `peminjaman`
  ADD CONSTRAINT `peminjaman_ibfk_1` FOREIGN KEY (`id_buku`) REFERENCES `buku` (`id`),
  ADD CONSTRAINT `peminjaman_ibfk_2` FOREIGN KEY (`id_anggota`) REFERENCES `anggota` (`id`);

--
-- Constraints for table `pengembalian`
--
ALTER TABLE `pengembalian`
  ADD CONSTRAINT `pengembalian_ibfk_1` FOREIGN KEY (`id_peminjaman`) REFERENCES `peminjaman` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
