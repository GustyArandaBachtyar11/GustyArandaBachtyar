<?php
// -------------------------------------------
// BAGIAN PHP: CEK LOGIN DAN SESSION USER
// -------------------------------------------

// Memulai session agar dapat menggunakan data session seperti username
session_start();

// Mengecek apakah user sudah login dengan memeriksa apakah session 'username' tersedia
// Jika tidak ditemukan (belum login), maka redirect ke halaman login.php
if (!isset($_SESSION['username'])) {
    header("Location: login.php"); // Arahkan kembali ke halaman login
    exit; // Hentikan eksekusi script setelah redirect
}
?>

<!DOCTYPE html>
<html>
<head>
    <!-- Judul halaman yang ditampilkan di tab browser -->
    <title>Dashboard Admin</title>

    <!-- Menambahkan file CSS Bootstrap v5.3.0 dari CDN untuk tampilan responsif -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">

    <!-- Import font Roboto dari Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">

    <!-- Style CSS khusus untuk mempercantik tampilan dashboard -->
    <style>
        body {
            /* Mengatur font default seluruh halaman */
            font-family: 'Roboto', sans-serif;

            /* Menambahkan background gambar */
            background: url('https://i.redd.it/ofe5l4d9e0m61.png') no-repeat center center fixed;

            /* Ukuran gambar background memenuhi layar */
            background-size: cover;
            position: relative;
        }

        body::before {
            /* Overlay gelap agar teks dan elemen terlihat jelas */
            content: "";
            position: fixed;
            top: 0; left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.6); /* Transparansi 60% hitam */
            z-index: -1; /* Supaya berada di belakang konten */
        }

        .navbar-brand {
            font-weight: bold; /* Menebalkan nama brand navbar */
        }

        .card {
            /* Efek transisi ketika hover */
            transition: 0.3s;
            border-radius: 15px; /* Sudut kartu membulat */
            background-color: rgba(255, 255, 255, 0.95); /* Warna latar semi-transparan */
        }

        .card:hover {
            /* Efek mengangkat saat di-hover */
            transform: translateY(-5px);
            box-shadow: 0 12px 20px rgba(0, 0, 0, 0.15);
        }

        h2 {
            font-weight: 600; /* Lebih tebal dari normal */
            color: white; /* Warna judul putih */
        }

        p.lead {
            color: #e0e0e0; /* Warna abu-abu terang untuk subjudul */
        }

        footer {
            margin-top: 60px;
            padding: 20px 0;
            text-align: center;
            background-color: rgba(255, 255, 255, 0.85); /* Latar belakang footer */
            color: #333; /* Warna teks */
            font-size: 14px;
        }
    </style>
</head>
<body>

<!--
--------------------------------------
NAVBAR UTAMA DASHBOARD
--------------------------------------
-->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
    <div class="container">
        <!-- Nama brand perpustakaan -->
        <a class="navbar-brand fw-bold" href="dashboard.php">📚 Perpustakaan Digital</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMenu">
            <span class="navbar-toggler-icon"></span>

        <!-- Tombol toggle navbar saat tampilan kecil -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMenu">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Menu navigasi -->
        <div class="collapse navbar-collapse justify-content-between" id="navbarMenu">
            <ul class="navbar-nav">
                <!-- Link navigasi ke halaman-halaman lain -->
                <li class="nav-item"><a class="nav-link" href="data_buku.php">📖 Data Buku</a></li>
                <li class="nav-item"><a class="nav-link" href="data_anggota.php">🧑‍🤝‍🧑 Data Anggota</a></li>
                <li class="nav-item"><a class="nav-link" href="data_petugas.php">👮‍♂️ Data Petugas</a></li>
                <li class="nav-item"><a class="nav-link" href="peminjaman.php">📅 Peminjaman</a></li>
                <li class="nav-item"><a class="nav-link" href="pengembalian.php">📤 Pengembalian</a></li>
                <li class="nav-item"><a class="nav-link" href="searching_buku.php">🔍 Cari Buku</a></li>
                <li class="nav-item"><a class="nav-link" href="laporan.php">📊 Laporan Transaksi</a></li>
                <li class="nav-item"><a class="nav-link" href="kategori.php">🏷️ Kategori Buku</a></li>
            </ul>

            <!-- Menu logout -->
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">🚪 Logout</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!--
--------------------------------------
ISI UTAMA HALAMAN DASHBOARD
--------------------------------------
-->
<div class="container mt-5">
    <!-- Sambutan kepada user yang login -->
    <div class="text-center mb-4">
        <h2>Selamat Datang, 
            <span class="text-warning"><?php echo $_SESSION['username']; ?></span>!
        </h2>
        <p class="lead">Ini adalah halaman dashboard admin perpustakaan.</p>
    </div>

    <!--
    ----------------------------------
    MENAMPILKAN KARTU MENU FITUR
    ----------------------------------
    -->
    <div class="row g-4">
        <?php
        // Membuat array $menus yang berisi pasangan [label, link halaman]
        $menus = [
            ["📖 Data Buku", "data_buku.php"],
            ["🧑‍🤝‍🧑 Data Anggota", "data_anggota.php"],
            ["👮 Data Petugas", "data_petugas.php"],
            ["📅 Peminjaman", "peminjaman.php"],
            ["📤 Pengembalian", "pengembalian.php"],
            ["🔍 Cari Buku", "searching_buku.php"],
            ["📊 Laporan Transaksi", "laporan.php"],
            ["🏷️ Kategori Buku", "kategori.php"]
        ];

        // Melakukan looping untuk setiap item menu
        foreach ($menus as $menu) {
            // Menampilkan kartu dengan judul dan tombol untuk membuka halaman terkait
            echo '
            <div class="col-md-3">
                <div class="card text-center shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title">'.$menu[0].'</h5>
                        <a href="'.$menu[1].'" class="btn btn-outline-primary mt-2">Buka</a>
                    </div>
                </div>
            </div>';
        }
        ?>
    </div>
</div>

<!--
----------------------------------
FOOTER HALAMAN
----------------------------------
-->
<footer class="text-center py-3" style="margin-top: 80px; background-color: rgba(255,255,255,0.9); color: black; font-weight: 500;">
    <!-- Menampilkan hak cipta dan identitas pembuat -->
    &copy; <?= date('Y'); ?> Gusty Aranda Bachtyar - 2023230023.
</footer>

<!-- Script JavaScript Bootstrap agar tombol toggle dan komponen JS berfungsi -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

