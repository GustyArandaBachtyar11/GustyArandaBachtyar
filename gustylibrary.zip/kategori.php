<?php
// Memulai session untuk mengecek apakah pengguna sudah login
session_start();

// Jika pengguna belum login (session username belum di-set), arahkan ke halaman login.php
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit; // Menghentikan eksekusi kode setelah redirect
}

// Menghubungkan ke database melalui file koneksi.php
include 'koneksi.php';

// Proses ketika tombol simpan ditekan
if (isset($_POST['simpan'])) {
    // Mengamankan inputan dari user terhadap karakter khusus
    $nama_kategori = mysqli_real_escape_string($conn, $_POST['nama_kategori']);

    // Menyimpan data kategori baru ke database
    mysqli_query($conn, "INSERT INTO kategori (nama) VALUES ('$nama_kategori')");

    // Setelah menyimpan, arahkan kembali ke halaman kategori.php
    header("Location: kategori.php");
}

// Mengambil seluruh data kategori dari database dan mengurutkan berdasarkan id secara menurun
$result = mysqli_query($conn, "SELECT * FROM kategori ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>📂 Kategori Buku</title>
    <!-- Link CSS Bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            background: url('https://i.redd.it/or199bc86sn91.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: 'Segoe UI', sans-serif;
            position: relative;
        }
        body::before {
            content: "";
            position: fixed;
            top: 0; left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255,255,255,0.3);
            z-index: -1; /* Supaya berada di belakang konten utama */
        }
        .navbar {
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        .content-card {
            background-color: rgba(255, 255, 255, 0.15);
            border-radius: 20px;
            padding: 30px;
            margin-top: 50px;
            color: #fff;
            backdrop-filter: blur(6px);
        }
        h3.title {
            font-weight: bold;
            color: #fff;
        }
        .table thead {
            background-color: rgba(13, 110, 253, 0.9);
            color: white;
        }
        .table td, .table th {
            vertical-align: middle;
            background-color: rgba(255,255,255,0.1);
            color: white;
        }
        a.text-decoration-none {
            color: #ffc107;
        }
        footer {
            margin-top: 60px;
            padding: 20px 0;
            text-align: center;
            background-color: rgba(255, 255, 255, 0.85);
            color: #000;
            font-size: 14px;
            font-weight: 500;
        }
    </style>
</head>
<body>

<!-- Navbar menu navigasi utama -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand fw-bold" href="dashboard.php">📚 Perpustakaan Digital</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-between" id="navbarMenu">
            <!-- Menu Kiri -->
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="data_buku.php">📖 Data Buku</a></li>
                <li class="nav-item"><a class="nav-link" href="data_anggota.php">🧑‍🤝‍🧑 Data Anggota</a></li>
                <li class="nav-item"><a class="nav-link" href="data_petugas.php">👮‍♂️ Data Petugas</a></li>
                <li class="nav-item"><a class="nav-link" href="peminjaman.php">📅 Peminjaman</a></li>
                <li class="nav-item"><a class="nav-link" href="pengembalian.php">📤 Pengembalian</a></li>
                <li class="nav-item"><a class="nav-link" href="searching_buku.php">🔍 Cari Buku</a></li>
                <li class="nav-item"><a class="nav-link" href="laporan.php">📊 Laporan Transaksi</a></li>
                <li class="nav-item"><a class="nav-link active" href="kategori.php">🏷️ Kategori Buku</a></li>
            </ul>
            <!-- Menu Kanan -->
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">🚪 Logout</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Konten Utama -->
<div class="container">
    <div class="content-card">
        <h3 class="mb-4 title">📂 Data Kategori Buku</h3>

        <!-- Tombol kembali dan tambah kategori -->
        <div class="d-flex justify-content-between align-items-center mb-3">
            <a href="dashboard.php" class="btn btn-success">&larr; Halaman Sebelumnya</a>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalTambah">+ Tambah Kategori</button>
        </div>

        <!-- Tabel daftar kategori -->
        <div class="table-responsive">
            <table class="table table-bordered table-hover text-center">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>📁 Nama Kategori</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1; // Nomor urut baris
                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                    ?>
                    <tr>
                        <td><?= $no++; ?></td>
                        <td>
                            <!-- Link ke halaman buku berdasarkan kategori -->
                            <a href="buku_kategori.php?id=<?= $row['id']; ?>" class="text-decoration-none">
                                <?= $row['nama']; ?>
                            </a>
                        </td>
                    </tr>
                    <?php } } else { ?>
                    <tr>
                        <td colspan="2" class="text-light">❗ Belum ada kategori ditambahkan.</td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal Tambah Kategori -->
<div class="modal fade" id="modalTambah">
  <div class="modal-dialog">
    <form method="post" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">➕ Tambah Kategori</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-2">
            <label>Nama Kategori</label>
            <input type="text" name="nama_kategori" class="form-control" required>
        </div>
      </div>
      <div class="modal-footer">
        <button name="simpan" class="btn btn-primary">Simpan</button>
      </div>
    </form>
  </div>
</div>

<!-- Footer halaman -->
<footer>
    &copy; <?= date('Y'); ?> Gusty Aranda Bachtyar - 2023230023.
</footer>

<!-- Script Bootstrap untuk modal dan elemen interaktif -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>