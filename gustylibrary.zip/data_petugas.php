<?php
// Memulai sesi untuk memastikan pengguna sudah login
session_start();

// Mengecek apakah sesi username tidak ada, jika iya maka arahkan ke halaman login
if (!isset($_SESSION['username'])) {
    header("Location: login.php"); // Redirect ke halaman login
    exit; // Menghentikan eksekusi script
}

// Menyisipkan file koneksi untuk terhubung ke database
include 'koneksi.php';

// Proses tambah data petugas jika tombol 'simpan' ditekan
if (isset($_POST['simpan'])) {
    $nama = $_POST['nama']; // Menangkap data nama dari form
    $no_hp = $_POST['no_hp']; // Menangkap data no_hp dari form

    // Menjalankan query INSERT untuk menambahkan petugas ke database
    mysqli_query($conn, "INSERT INTO petugas (nama, no_hp) VALUES ('$nama', '$no_hp')");

    // Redirect kembali ke halaman data_petugas.php
    header("Location: data_petugas.php");
}

// Proses hapus petugas jika parameter 'hapus' ada di URL
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus']; // Menyimpan ID petugas yang akan dihapus

    // Menjalankan query DELETE berdasarkan ID
    mysqli_query($conn, "DELETE FROM petugas WHERE id = $id");

    // Redirect kembali ke halaman data_petugas.php
    header("Location: data_petugas.php");
}

// Proses update data petugas jika tombol 'update' ditekan
if (isset($_POST['update'])) {
    $id = $_POST['id']; // Menangkap ID dari form tersembunyi
    $nama = $_POST['nama']; // Menangkap nama baru
    $no_hp = $_POST['no_hp']; // Menangkap nomor HP baru

    // Menjalankan query UPDATE untuk memperbarui data petugas
    mysqli_query($conn, "UPDATE petugas SET nama='$nama', no_hp='$no_hp' WHERE id=$id");

    // Redirect kembali ke halaman data_petugas.php
    header("Location: data_petugas.php");
}

// Mengambil seluruh data petugas dari database, diurutkan dari ID terbesar
$result = mysqli_query($conn, "SELECT * FROM petugas ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Petugas</title>
    <!-- Link CSS Bootstrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        /* Styling latar belakang */
        body {
            background: url('https://i.redd.it/rbued4durtc81.png') no-repeat center center fixed;
            background-size: cover;
            font-family: 'Segoe UI', sans-serif;
            position: relative;
        }
        body::before {
            content: "";
            position: fixed;
            top: 0; left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255,255,255,0.6);
            z-index: -1;
        }
        .navbar {
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .table thead {
            background-color: #2c3e50;
            color: white;
        }
        .card-box {
            background: rgba(255, 255, 255, 0.95);
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.08);
        }
    </style>
</head>
<body>

<!-- Navbar utama aplikasi -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
    <a class="navbar-brand fw-bold" href="dashboard.php">📚 Perpustakaan Digital</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-between" id="navbarMenu">
            <ul class="navbar-nav">
                <!-- Menu navigasi -->
                <li class="nav-item"><a class="nav-link" href="data_buku.php">📖 Data Buku</a></li>
                <li class="nav-item"><a class="nav-link" href="data_anggota.php">🧑‍🤝‍🧑 Data Anggota</a></li>
                <li class="nav-item"><a class="nav-link active" href="data_petugas.php">👮‍♂️ Data Petugas</a></li>
                <li class="nav-item"><a class="nav-link" href="peminjaman.php">📅 Peminjaman</a></li>
                <li class="nav-item"><a class="nav-link" href="pengembalian.php">📤 Pengembalian</a></li>
                <li class="nav-item"><a class="nav-link" href="searching_buku.php">🔍 Cari Buku</a></li>
                <li class="nav-item"><a class="nav-link" href="laporan.php">📊 Laporan Transaksi</a></li>
                <li class="nav-item"><a class="nav-link" href="kategori.php">🏷️ Kategori Buku</a></li>
            </ul>
            <ul class="navbar-nav">
                <!-- Menu logout -->
                <li class="nav-item"><a class="nav-link" href="logout.php">🚪 Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<!-- Bagian konten utama -->
<div class="container mt-4">
    <!-- Header dan tombol tambah petugas -->
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3 class="text-primary">👮‍♂️ Data Petugas</h3>
        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modalTambah">+ Tambah Petugas</button>
    </div>

    <!-- Tabel data petugas -->
    <div class="card-box">
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Petugas</th>
                    <th>No. HP</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; while ($row = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td><?= $no++; ?></td> <!-- Menampilkan nomor urut -->
                    <td><?= $row['nama']; ?></td> <!-- Menampilkan nama petugas -->
                    <td><?= $row['no_hp']; ?></td> <!-- Menampilkan nomor HP -->
                    <td>
                        <!-- Tombol edit dan hapus -->
                        <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#modalEdit<?= $row['id']; ?>">✏️</button>
                        <a href="?hapus=<?= $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin hapus data ini?')">🗑️</a>
                    </td>
                </tr>

                <!-- Modal edit petugas -->
                <div class="modal fade" id="modalEdit<?= $row['id']; ?>">
                    <div class="modal-dialog">
                        <form method="post" class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Edit Petugas</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                <input type="hidden" name="id" value="<?= $row['id']; ?>">
                                <div class="mb-2">
                                    <label>Nama</label>
                                    <input type="text" name="nama" class="form-control" value="<?= $row['nama']; ?>" required>
                                </div>
                                <div class="mb-2">
                                    <label>No. HP</label>
                                    <input type="text" name="no_hp" class="form-control" value="<?= $row['no_hp']; ?>" required>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button class="btn btn-primary" name="update">💾 Simpan</button>
                            </div>
                        </form>
                    </div>
                </div>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal tambah petugas baru -->
<div class="modal fade" id="modalTambah">
    <div class="modal-dialog">
        <form method="post" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Tambah Petugas</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-2">
                    <label>Nama</label>
                    <input type="text" name="nama" class="form-control" placeholder="Masukkan nama petugas" required>
                </div>
                <div class="mb-2">
                    <label>No. HP</label>
                    <input type="text" name="no_hp" class="form-control" placeholder="Masukkan no HP" required>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-success" name="simpan">💾 Simpan</button>
            </div>
        </form>
    </div>
</div>

<!-- Footer halaman -->
<footer class="text-center py-3 mt-4" style="background-color: rgba(255,255,255,0.9); color: #333; font-weight: 500;">
    &copy; <?= date('Y'); ?> Gusty Aranda Bachtyar - 2023230023.
</footer>

<!-- Menyisipkan Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
