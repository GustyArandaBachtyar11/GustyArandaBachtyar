<?php
// Memulai session agar kita bisa memeriksa apakah user sudah login
session_start();

// Jika belum login, arahkan kembali ke halaman login
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

// Menyambungkan ke database menggunakan koneksi.php
include 'koneksi.php';


// -----------------------------
// TAMBAH DATA BUKU
// -----------------------------
if (isset($_POST['simpan'])) {
    // Ambil data dari form input
    $judul = $_POST['judul'];
    $pengarang = $_POST['pengarang'];
    $penerbit = $_POST['penerbit'];
    $tahun = $_POST['tahun'];

    // Ambil file gambar sampul yang diupload
    $nama_file = $_FILES['sampul']['name'];          // nama file
    $tmp = $_FILES['sampul']['tmp_name'];            // lokasi sementara file
    $path = 'uploads/' . $nama_file;                 // path tujuan upload

    // Jika file ada, pindahkan ke folder uploads
    if ($nama_file != '') move_uploaded_file($tmp, $path);
    else $nama_file = ''; // Jika tidak upload, kosongkan

    // Masukkan data ke database
    mysqli_query($conn, "INSERT INTO buku (judul, pengarang, penerbit, tahun, sampul)
                         VALUES ('$judul', '$pengarang', '$penerbit', '$tahun', '$nama_file')");

    // Redirect kembali ke halaman data buku
    header("Location: data_buku.php");
}


// -----------------------------
// HAPUS DATA BUKU
// -----------------------------
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus']; // Ambil ID buku dari URL

    // Cek apakah ada file sampul yang perlu dihapus
    $data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT sampul FROM buku WHERE id=$id"));
    if ($data['sampul'] != '') unlink('uploads/' . $data['sampul']); // Hapus file jika ada

    // Hapus data buku dari database
    mysqli_query($conn, "DELETE FROM buku WHERE id = $id");

    // Redirect kembali
    header("Location: data_buku.php");
}


// -----------------------------
// UPDATE / EDIT DATA BUKU
// -----------------------------
if (isset($_POST['update'])) {
    $id = $_POST['id']; // ID buku yang diedit
    $judul = $_POST['judul'];
    $pengarang = $_POST['pengarang'];
    $penerbit = $_POST['penerbit'];
    $tahun = $_POST['tahun'];
    $sampul_baru = $_FILES['sampul']['name'];
    $tmp = $_FILES['sampul']['tmp_name'];

    if ($sampul_baru != '') {
        // Jika user upload sampul baru, pindahkan filenya
        move_uploaded_file($tmp, 'uploads/' . $sampul_baru);

        // Update data termasuk nama file sampul
        mysqli_query($conn, "UPDATE buku SET judul='$judul', pengarang='$pengarang', penerbit='$penerbit', tahun='$tahun', sampul='$sampul_baru' WHERE id=$id");
    } else {
        // Jika tidak ada sampul baru, update tanpa mengganti sampul
        mysqli_query($conn, "UPDATE buku SET judul='$judul', pengarang='$pengarang', penerbit='$penerbit', tahun='$tahun' WHERE id=$id");
    }

    header("Location: data_buku.php");
}


// -----------------------------
// PENCARIAN BUKU
// -----------------------------
$keyword = isset($_GET['search']) ? $_GET['search'] : ''; // Ambil kata kunci pencarian
$query = "SELECT * FROM buku WHERE judul LIKE '%$keyword%' OR pengarang LIKE '%$keyword%' ORDER BY id DESC";
$result = mysqli_query($conn, $query); // Jalankan query pencarian
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Buku</title>
    <!-- CSS Bootstrap untuk desain responsif -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        /* Styling background dan komponen visual */
        body {
            background: url('https://i.imgur.com/W8Egih8.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: 'Segoe UI', sans-serif;
            
        }
        body::before {
            content: "";
            position: fixed;
            top: 0; left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255,255,255,0.5);
            z-index: -1;
        }
        .table thead {
            background-color: #343a40;
            color: white;
        }
        .navbar {
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .card-table {
            background: rgba(255, 255, 255, 0.9);
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.05);
        }
        .btn-sm {
            padding: 4px 10px;
            font-size: 0.85rem;
        }
        .form-control:focus {
            border-color: #0d6efd;
            box-shadow: 0 0 0 0.2rem rgba(13, 110, 253, 0.25);
        }
        img.thumb {
            width: 60px;
            border-radius: 5px;
        }
    </style>
</head>
<body>

<!-- NAVBAR UTAMA -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
    <a class="navbar-brand fw-bold" href="dashboard.php">📚 Perpustakaan Digital</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-between" id="navbarMenu">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link active" href="data_buku.php">📖 Data Buku</a></li>
                <li class="nav-item"><a class="nav-link" href="data_anggota.php">🧑‍🤝‍🧑 Data Anggota</a></li>
                <li class="nav-item"><a class="nav-link" href="data_petugas.php">👮‍♂️ Data Petugas</a></li>
                <li class="nav-item"><a class="nav-link" href="peminjaman.php">📅 Peminjaman</a></li>
                <li class="nav-item"><a class="nav-link" href="pengembalian.php">📤 Pengembalian</a></li>
                <li class="nav-item"><a class="nav-link" href="searching_buku.php">🔍 Cari Buku</a></li>
                <li class="nav-item"><a class="nav-link" href="laporan.php">📊 Laporan Transaksi</a></li>
                <li class="nav-item"><a class="nav-link" href="kategori.php">🏷️ Kategori Buku</a></li>
            </ul>
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="logout.php">🚪 Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<!-- ISI HALAMAN -->
<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3 class="text-primary">📖 Data Buku</h3>
        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modalTambah">+ Tambah Buku</button>
    </div>

    <!-- FORM PENCARIAN -->
    <form method="get" class="row g-2 mb-3">
        <div class="col-md-10">
            <input type="text" name="search" class="form-control" placeholder="🔍 Cari judul atau pengarang..." value="<?= $keyword; ?>">
        </div>
        <div class="col-md-2">
            <button class="btn btn-primary w-100">Cari</button>
        </div>
    </form>

    <!-- TABEL DATA -->
    <div class="card-table">
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Sampul</th>
                    <th>Judul</th>
                    <th>Pengarang</th>
                    <th>Penerbit</th>
                    <th>Tahun</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; while ($row = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td><?= $row['sampul'] ? "<img src='uploads/{$row['sampul']}' class='thumb'>" : '-' ?></td>
                    <td><?= $row['judul']; ?></td>
                    <td><?= $row['pengarang']; ?></td>
                    <td><?= $row['penerbit']; ?></td>
                    <td><?= $row['tahun']; ?></td>
                    <td>
                        <!-- Tombol Edit -->
                        <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#modalEdit<?= $row['id']; ?>">✏️ Edit</button>

                        <!-- Tombol Hapus -->
                        <a href="?hapus=<?= $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Hapus data ini?')">🗑️ Hapus</a>
                    </td>
                </tr>

                <!-- MODAL EDIT BUKU -->
                <div class="modal fade" id="modalEdit<?= $row['id']; ?>">
                    <div class="modal-dialog">
                        <form method="post" class="modal-content" enctype="multipart/form-data">
                            <div class="modal-header"><h5>Edit Buku</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                            <div class="modal-body">
                                <input type="hidden" name="id" value="<?= $row['id']; ?>">
                                <div class="mb-2"><label>Judul</label><input type="text" name="judul" class="form-control" value="<?= $row['judul']; ?>" required></div>
                                <div class="mb-2"><label>Pengarang</label><input type="text" name="pengarang" class="form-control" value="<?= $row['pengarang']; ?>" required></div>
                                <div class="mb-2"><label>Penerbit</label><input type="text" name="penerbit" class="form-control" value="<?= $row['penerbit']; ?>" required></div>
                                <div class="mb-2"><label>Tahun</label><input type="number" name="tahun" class="form-control" value="<?= $row['tahun']; ?>" required></div>
                                <div class="mb-2"><label>Ganti Sampul (opsional)</label><input type="file" name="sampul" class="form-control" accept="image/*"></div>
                            </div>
                            <div class="modal-footer"><button class="btn btn-primary" name="update">💾 Simpan Perubahan</button></div>
                        </form>
                    </div>
                </div>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<!-- MODAL TAMBAH BUKU -->
<div class="modal fade" id="modalTambah">
    <div class="modal-dialog">
        <form method="post" class="modal-content" enctype="multipart/form-data">
            <div class="modal-header"><h5>Tambah Buku</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body">
                <div class="mb-2"><label>Judul</label><input type="text" name="judul" class="form-control" required></div>
                <div class="mb-2"><label>Pengarang</label><input type="text" name="pengarang" class="form-control" required></div>
                <div class="mb-2"><label>Penerbit</label><input type="text" name="penerbit" class="form-control" required></div>
                <div class="mb-2"><label>Tahun</label><input type="number" name="tahun" class="form-control" required></div>
                <div class="mb-2"><label>Sampul (gambar)</label><input type="file" name="sampul" class="form-control" accept="image/*"></div>
            </div>
            <div class="modal-footer"><button class="btn btn-success" name="simpan">💾 Simpan</button></div>
        </form>
    </div>
</div>

<!-- FOOTER -->
<footer class="text-center py-3 mt-4" style="background-color: rgba(255,255,255,0.9); color: #333; font-weight: 500;">
    &copy; <?= date('Y'); ?> Gusty Aranda Bachtyar - 2023230023.
</footer>

<!-- Script Bootstrap -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
