<?php
// Memulai sesi untuk mengecek apakah pengguna telah login
session_start();

// Jika pengguna belum login, redirect ke halaman login
if (!isset($_SESSION['username'])) {
    header("Location: login.php"); // Arahkan ke login.php jika belum login
    exit; // Hentikan eksekusi script
}

// Menghubungkan ke database
include 'koneksi.php';

// Proses penambahan data peminjaman
if (isset($_POST['simpan'])) {
    $id_buku = $_POST['id_buku']; // Ambil ID buku dari input form
    $id_anggota = $_POST['id_anggota']; // Ambil ID anggota dari input form
    $tanggal_pinjam = $_POST['tanggal_pinjam']; // Ambil tanggal pinjam dari input form

    // Menyimpan data peminjaman ke database
    mysqli_query($conn, "INSERT INTO peminjaman (id_buku, id_anggota, tanggal_pinjam) 
                         VALUES ('$id_buku', '$id_anggota', '$tanggal_pinjam')");

    // Redirect kembali ke halaman peminjaman setelah simpan
    header("Location: peminjaman.php");
}

// Mengambil data peminjaman lengkap dengan relasi judul buku dan nama anggota
$result = mysqli_query($conn, "
    SELECT p.id, b.judul, a.nama, p.tanggal_pinjam 
    FROM peminjaman p
    JOIN buku b ON p.id_buku = b.id
    JOIN anggota a ON p.id_anggota = a.id
    ORDER BY p.id DESC
");

// Mengambil seluruh data buku untuk digunakan dalam dropdown tambah peminjaman
$buku = mysqli_query($conn, "SELECT * FROM buku");

// Mengambil seluruh data anggota untuk digunakan dalam dropdown tambah peminjaman
$anggota = mysqli_query($conn, "SELECT * FROM anggota");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Peminjaman</title>
    <!-- Import Bootstrap CSS versi 5 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        /* Styling background dan tampilan body */
        body {
            background-image: url('https://i.redd.it/ys2b9z6gtq671.png');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            min-height: 100vh;
            backdrop-filter: brightness(0.95);
        }
        .navbar {
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
        }
        .card-box {
            background: rgba(255, 255, 255, 0.95);
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.08);
        }
        .modal-title {
            font-weight: bold;
        }
    </style>
</head>
<body>

<!-- Navbar Navigasi -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
    <a class="navbar-brand fw-bold" href="dashboard.php">📚 Perpustakaan Digital</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-between" id="navbarMenu">
            <!-- Menu Navigasi Kiri -->
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="data_buku.php">📖 Data Buku</a></li>
                <li class="nav-item"><a class="nav-link" href="data_anggota.php">🧑‍🤝‍🧑 Data Anggota</a></li>
                <li class="nav-item"><a class="nav-link" href="data_petugas.php">👮‍♂️ Data Petugas</a></li>
                <li class="nav-item"><a class="nav-link active" href="peminjaman.php">📅 Peminjaman</a></li>
                <li class="nav-item"><a class="nav-link" href="pengembalian.php">📤 Pengembalian</a></li>
                <li class="nav-item"><a class="nav-link" href="searching_buku.php">🔍 Cari Buku</a></li>
                <li class="nav-item"><a class="nav-link" href="laporan.php">📊 Laporan Transaksi</a></li>
                <li class="nav-item"><a class="nav-link" href="kategori.php">🏷️ Kategori Buku</a></li>
            </ul>
            <!-- Menu Navigasi Kanan -->
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="logout.php">🚪 Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<!-- Konten Utama -->
<div class="container mt-4">
    <!-- Judul dan Tombol Tambah -->
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3 class="text-primary">📅 Data Peminjaman Buku</h3>
        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modalTambah">+ Tambah Peminjaman</button>
    </div>

    <!-- Tabel Peminjaman -->
    <div class="card-box">
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Judul Buku</th>
                    <th>Nama Anggota</th>
                    <th>Tanggal Pinjam</th>
                </tr>
            </thead>
            <tbody>
                <!-- Menampilkan data hasil query ke dalam tabel -->
                <?php $no = 1; while ($row = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td><?= $row['judul']; ?></td>
                    <td><?= $row['nama']; ?></td>
                    <td><?= date('d M Y', strtotime($row['tanggal_pinjam'])); ?></td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Tambah Peminjaman -->
<div class="modal fade" id="modalTambah">
  <div class="modal-dialog">
    <form method="post" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">📝 Tambah Peminjaman</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <!-- Dropdown Buku -->
        <div class="mb-3">
            <label class="form-label">📖 Buku</label>
            <select name="id_buku" class="form-select" required>
                <option value="">-- Pilih Buku --</option>
                <?php while ($b = mysqli_fetch_assoc($buku)) { ?>
                    <option value="<?= $b['id']; ?>"><?= $b['judul']; ?></option>
                <?php } ?>
            </select>
        </div>
        <!-- Dropdown Anggota -->
        <div class="mb-3">
            <label class="form-label">👤 Anggota</label>
            <select name="id_anggota" class="form-select" required>
                <option value="">-- Pilih Anggota --</option>
                <?php while ($a = mysqli_fetch_assoc($anggota)) { ?>
                    <option value="<?= $a['id']; ?>"><?= $a['nama']; ?></option>
                <?php } ?>
            </select>
        </div>
        <!-- Input Tanggal Pinjam -->
        <div class="mb-3">
            <label class="form-label">🗓 Tanggal Pinjam</label>
            <input type="date" name="tanggal_pinjam" class="form-control" required>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-success" name="simpan">💾 Simpan</button>
      </div>
    </form>
  </div>
</div>

<!-- Footer -->
<footer class="text-center py-3 mt-4" style="background-color: rgba(255,255,255,0.9); color: #333; font-weight: 500;">
    &copy; <?= date('Y'); ?> Gusty Aranda Bachtyar - 2023230023.
</footer>

<!-- Import file JavaScript Bootstrap -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
