<?php
// koneksi.php
// Membuat koneksi ke database MySQL

$host = "localhost"; // Nama host database
$user = "root";      // Username default MySQL di XAMPP
$pass = "";          // Password default (kosong)
$db   = "db_perpustakaan"; // Nama database yang digunakan

// Membuat koneksi ke database
$conn = mysqli_connect($host, $user, $pass, $db);

// Mengecek apakah koneksi berhasil
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error()); // Jika gagal tampilkan pesan error
}
?>
