<?php
// Memulai session untuk mengecek apakah user sudah login
session_start();

// Jika user belum login, arahkan ke halaman login
if (!isset($_SESSION['username'])) {
    header("Location: login.php"); // Redirect ke login.php
    exit; // Hentikan proses agar tidak mengeksekusi halaman
}

// Memanggil koneksi ke database
include 'koneksi.php'; // Menghubungkan dengan file koneksi.php

// Mengambil ID kategori dari parameter URL (GET)
$id_kategori = isset($_GET['id']) ? (int)$_GET['id'] : 0; // Konversi ke integer untuk keamanan

// Ambil nama kategori berdasarkan ID
$kategori = mysqli_query($conn, "SELECT nama FROM kategori WHERE id = $id_kategori");

// Jika tidak ada data kategori, tampilkan pesan error dan hentikan eksekusi
if (mysqli_num_rows($kategori) == 0) {
    die("Kategori tidak ditemukan."); // Menampilkan pesan jika kategori tidak ada
}

// Simpan nama kategori ke dalam variabel
$nama_kategori = mysqli_fetch_assoc($kategori)['nama']; // Mengambil nama dari hasil query

// Ambil daftar buku berdasarkan ID kategori
$result = mysqli_query($conn, "SELECT * FROM buku WHERE id_kategori = $id_kategori");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8"> <!-- Mengatur encoding karakter -->
    <title>Daftar Buku: <?= htmlspecialchars($nama_kategori); ?></title> <!-- Judul dinamis -->

    <!-- Import Bootstrap CSS dari CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- CSS Tambahan -->
    <style>
        /* Mengatur tinggi penuh dan menghilangkan margin bawaan */
        html, body {
            height: 100%; /* Tinggi minimum 100% dari viewport */
            margin: 0;     /* Hilangkan margin bawaan browser */
        }

        /* Mengatur background gambar di seluruh halaman */
        body {
            background-image: url('https://i.redd.it/i-built-a-library-for-every-enchantment-in-minecraft-v0-xg8jmd34udvc1.png?width=1920&format=png&auto=webp&s=5fa49ac4e8b906d0e83f2a8499b983a2b445d1b7'); /* Gambar background */
            background-size: cover;       /* Gambar mengisi seluruh layar */
            background-position: center;  /* Pusatkan gambar */
            background-attachment: fixed; /* Background tetap saat scroll */
            font-family: 'Segoe UI', sans-serif; /* Font utama halaman */
        }

        /* Tampilan overlay putih transparan untuk kotak isi */
        .overlay {
            background-color: rgba(255, 255, 255, 0.9); /* Putih semi-transparan */
            padding: 2rem;             /* Spasi dalam kontainer */
            border-radius: 10px;       /* Sudut membulat */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2); /* Bayangan lembut */
        }

        /* Styling judul halaman */
        .title {
            color: #007bff;       /* Biru khas Bootstrap */
            font-weight: 700;     /* Teks tebal */
        }

        /* Warna dan styling header tabel */
        .table th {
            background-color: #e9f5ff; /* Biru sangat muda */
            color: #212529;            /* Abu gelap */
        }

        /* Pesan jika tidak ada data */
        .no-data {
            color: #dc3545; /* Merah Bootstrap */
        }

        /* Styling footer */
        footer {
            background-color: rgba(255, 255, 255, 0.8); /* Warna putih transparan */
            color: #333;             /* Warna teks abu tua */
            font-weight: 500;        /* Teks sedang tebal */
        }
    </style>
</head>

<!-- 
    Body dijadikan flex container vertikal agar footer bisa menempel ke bawah
-->
<body class="min-vh-100 d-flex flex-column">
<!-- 
    min-vh-100  : tinggi minimum 100% dari viewport
    d-flex      : gunakan Flexbox
    flex-column : arah layout vertikal
-->

    <!-- Kontainer utama -->
    <div class="container py-5 flex-grow-1">
        <!-- 
            container   : lebar responsif Bootstrap
            py-5        : padding vertikal atas dan bawah
            flex-grow-1 : memaksa konten ini memenuhi ruang kosong flex
        -->
        <div class="overlay"> <!-- Lapisan transparan agar teks terlihat jelas di atas background -->
            <h3 class="mb-4 title">📚 Daftar Buku Kategori: <?= htmlspecialchars($nama_kategori); ?></h3>
            <!-- Judul halaman sesuai nama kategori -->

            <!-- Tombol kembali ke halaman kategori -->
            <a href="kategori.php" class="btn btn-success mb-3 text-white">← Kembali ke Kategori</a>

            <!-- Tabel daftar buku -->
            <div class="table-responsive">
                <!-- Tabel responsif untuk mobile -->
                <table class="table table-bordered table-hover text-center align-middle shadow-sm">
                    <!-- 
                        table              : class Bootstrap untuk tabel
                        table-bordered     : border untuk semua sel
                        table-hover        : efek hover pada baris
                        text-center        : teks rata tengah
                        align-middle       : vertikal rata tengah
                        shadow-sm          : bayangan halus
                    -->
                    <thead class="table-light">
                        <tr>
                            <th>No</th>
                            <th>Judul</th>
                            <th>Pengarang</th>
                            <th>Penerbit</th>
                            <th>Tahun</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Periksa apakah hasil query memiliki data -->
                        <?php if (mysqli_num_rows($result) > 0): ?>
                            <?php $no = 1; while ($buku = mysqli_fetch_assoc($result)) : ?>
                                <tr>
                                    <td><?= $no++; ?></td> <!-- Nomor urut -->
                                    <td><?= htmlspecialchars($buku['judul']); ?></td> <!-- Judul buku -->
                                    <td><?= htmlspecialchars($buku['pengarang']); ?></td> <!-- Nama pengarang -->
                                    <td><?= htmlspecialchars($buku['penerbit']); ?></td> <!-- Nama penerbit -->
                                    <td><?= htmlspecialchars($buku['tahun']); ?></td> <!-- Tahun terbit -->
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <!-- Tampilkan pesan jika tidak ada data -->
                            <tr>
                                <td colspan="5" class="no-data">❗ Tidak ada buku dalam kategori ini.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Bagian footer tetap di dasar halaman -->
    <footer class="text-center py-3 mt-auto">
        <!-- 
            text-center : teks berada di tengah
            py-3        : padding atas dan bawah
            mt-auto     : margin-top otomatis, dorong ke dasar container flex
        -->
        &copy; <?= date('Y'); ?> Gusty Aranda Bachtyar - 2023230023.
        <!-- 
            &copy;             : simbol copyright
            date('Y')          : tahun saat ini (otomatis)
            Nama dan NIM       : identitas pembuat
        -->
    </footer>

</body>
</html>
