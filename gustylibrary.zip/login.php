<?php
// ---------------------------
// Bagian PHP: Proses Login
// ---------------------------

// Memulai session, agar bisa menyimpan data pengguna saat login ke server
session_start();

// Menghubungkan file koneksi.php yang berisi konfigurasi koneksi ke database MySQL
// File ini harus memiliki variabel koneksi aktif, misalnya $conn
include 'koneksi.php';

// Mendeklarasikan variabel $error yang akan menyimpan pesan kesalahan (jika login gagal)
$error = "";

// Mengecek apakah form login telah dikirimkan oleh pengguna
// Mengecek apakah tombol login diklik (melalui atribut name="login")
if (isset($_POST['login'])) {

    // Mengambil input 'username' dari form dan membersihkannya dari karakter berbahaya
    // Fungsi ini mencegah serangan SQL Injection
    $username = mysqli_real_escape_string($conn, $_POST['username']);

    // Mengambil input 'password' dari form tanpa pembersihan tambahan
    // Catatan: password belum dienkripsi atau di-hash (plaintext), sebaiknya menggunakan hashing seperti password_hash()
    $password = $_POST['password'];

    // Membuat query SQL untuk mencari data pengguna yang memiliki username dan password yang sesuai
    // Perlu diingat: jika password sudah di-hash di database, maka pencocokan harus menggunakan password_verify()
    $query = "SELECT * FROM users WHERE username='$username' AND password='$password'";

    // Menjalankan query SQL di atas menggunakan koneksi ke database
    $result = mysqli_query($conn, $query);

    // Mengecek apakah jumlah hasil pencarian = 1, berarti ditemukan user dengan username dan password yang cocok
    if (mysqli_num_rows($result) == 1) {

        // Menyimpan data username ke dalam session agar bisa digunakan di halaman lain
        $_SESSION['username'] = $username;

        // Mengarahkan (redirect) pengguna ke halaman dashboard.php
        header("Location: dashboard.php");
        exit; // Menghentikan proses PHP agar tidak mengeksekusi baris setelahnya
    } else {
        // Jika tidak ditemukan user yang cocok, set pesan error untuk ditampilkan di tampilan HTML
        $error = "Username atau password salah!";
    }
}
?>

<!--
-------------------------------------
Bagian HTML: Tampilan Form Login
-------------------------------------
-->
<!DOCTYPE html>
<html>
<head>
    <!-- Judul tab browser -->
    <title>Login Perpustakaan</title>

    <!-- Mengimpor library Bootstrap 5.3.0 untuk styling tampilan yang modern -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- CSS tambahan untuk mengatur tampilan halaman login -->
    <style>
        body {
            /* Menambahkan gambar latar belakang bertema Minecraft */
            background-image: url('https://4kwallpapers.com/images/wallpapers/minecraft-spring-to-1920x1080-21999.jpg');

            /* Menyusun background agar full screen dan tidak mengulang */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;

            /* Membuat tinggi body sesuai tinggi layar penuh */
            height: 100vh;

            /* Menengahkan isi halaman secara horizontal dan vertikal dengan Flexbox */
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .login-card {
            /* Warna putih dengan tingkat transparansi (opacity 0.95) */
            background: rgba(255, 255, 255, 0.95);

            /* Membuat tepi form membulat */
            border-radius: 15px;

            /* Menambahkan efek bayangan agar tampak mengambang */
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);

            /* Memberikan padding di dalam form login */
            padding: 30px;
        }
    </style>
</head>
<body>

<!-- Kontainer utama form login -->
<div class="login-card col-md-4">
    
    <!-- Judul form login dengan ikon dan teks berwarna biru -->
    <h4 class="text-center mb-4 text-primary">📚 Login Admin Perpustakaan</h4>

    <!-- Menampilkan pesan error jika proses login gagal -->
    <?php if ($error) echo "<div class='alert alert-danger'>$error</div>"; ?>

    <!-- Form login menggunakan metode POST agar data tidak terlihat di URL -->
    <form method="post">
        
        <!-- Form field untuk input username -->
        <div class="mb-3">
            <label class="form-label">👤 Username</label>
            <input type="text" name="username" class="form-control" required>
        </div>

        <!-- Form field untuk input password -->
        <div class="mb-3">
            <label class="form-label">🔒 Password</label>
            <input type="password" name="password" class="form-control" required>
        </div>

        <!-- Tombol untuk mengirim form login -->
        <button type="submit" name="login" class="btn btn-primary w-100">Login</button>
    </form>
</div>

</body>
</html>

